using Geometry.Domain.Common;

namespace Geometry.Domain.Shapes
{
    /// <summary>
    /// Represents a 3D cylinder with radius and height.
    /// </summary>
    public class Cylinder : Entity
    {
        /// <summary>
        /// Gets the radius of the cylinder.
        /// </summary>
        public double Radius { get; private set; }

        /// <summary>
        /// Gets the height of the cylinder.
        /// </summary>
        public double Height { get; private set; }

        public Cylinder(double radius, double height)
        {
            if (radius <= 0) throw new ArgumentException("Radius must be positive.");
            if (height <= 0) throw new ArgumentException("Height must be positive.");

            Radius = radius;
            Height = height;
        }

        /// <summary>
        /// Updates radius and height of the cylinder.
        /// </summary>
        public void Update(double radius, double height)
        {
            if (radius <= 0) throw new ArgumentException("Radius must be positive.");
            if (height <= 0) throw new ArgumentException("Height must be positive.");

            Radius = radius;
            Height = height;
        }
    }
}
