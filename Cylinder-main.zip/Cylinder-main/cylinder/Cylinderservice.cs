using Geometry.Domain.Interfaces;
using Geometry.Domain.Shapes;

namespace Geometry.Application.Services
{
    /// <summary>
    /// Application-level service for managing cylinders.
    /// </summary>
    public class CylinderService
    {
        private readonly ICylinderRepository _repo;

        public CylinderService(ICylinderRepository repo)
        {
            _repo = repo;
        }

        /// <summary>
        /// Creates and persists a new cylinder.
        /// </summary>
        public async Task<Guid> CreateAsync(double radius, double height)
        {
            var cylinder = new Cylinder(radius, height);
            await _repo.AddAsync(cylinder);
            return cylinder.Id;
        }

        /// <summary>
        /// Gets a cylinder by its ID.
        /// </summary>
        public Task<Cylinder?> GetAsync(Guid id) => _repo.GetAsync(id);

        /// <summary>
        /// Updates an existing cylinder.
        /// </summary>
        public async Task UpdateAsync(Guid id, double radius, double height)
        {
            var cylinder = await _repo.GetAsync(id)
                ?? throw new KeyNotFoundException("Cylinder not found.");

            cylinder.Update(radius, height);
            await _repo.UpdateAsync(cylinder);
        }

        /// <summary>
        /// Deletes an existing cylinder.
        /// </summary>
        public async Task DeleteAsync(Guid id) =>
            await _repo.DeleteAsync(id);
    }
}
