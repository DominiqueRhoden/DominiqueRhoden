using Geometry.Domain.Interfaces;
using Geometry.Domain.Shapes;
using Microsoft.EntityFrameworkCore;

namespace Geometry.Infrastructure.Repositories
{
    /// <summary>
    /// EF Core implementation of ICylinderRepository.
    /// </summary>
    public class CylinderRepository : ICylinderRepository
    {
        private readonly GeometryDbContext _context;

        public CylinderRepository(GeometryDbContext context)
        {
            _context = context;
        }

        public async Task<Cylinder?> GetAsync(Guid id) =>
            await _context.Cylinders.FindAsync(id);

        public async Task AddAsync(Cylinder cylinder)
        {
            await _context.Cylinders.AddAsync(cylinder);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Cylinder cylinder)
        {
            _context.Cylinders.Update(cylinder);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid id)
        {
            var cylinder = await _context.Cylinders.FindAsync(id);
            if (cylinder != null)
            {
                _context.Cylinders.Remove(cylinder);
                await _context.SaveChangesAsync();
            }
        }
    }
}
