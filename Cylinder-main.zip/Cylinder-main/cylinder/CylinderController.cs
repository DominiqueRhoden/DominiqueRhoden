using Geometry.Application.Services;
using Geometry.Domain.Shapes;
using Microsoft.AspNetCore.Mvc;

namespace Geometry.WebApi.Controllers
{
    /// <summary>
    /// API controller for CRUD operations on cylinders.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class CylinderController : ControllerBase
    {
        private readonly CylinderService _service;

        public CylinderController(CylinderService service)
        {
            _service = service;
        }

        /// <summary>
        /// Creates a new cylinder.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CylinderDto dto)
        {
            var id = await _service.CreateAsync(dto.Radius, dto.Height);
            return CreatedAtAction(nameof(Get), new { id }, new { id });
        }

        /// <summary>
        /// Gets a cylinder by ID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            var cylinder = await _service.GetAsync(id);
            return cylinder == null ? NotFound() : Ok(cylinder);
        }

        /// <summary>
        /// Updates an existing cylinder.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, [FromBody] CylinderDto dto)
        {
            await _service.UpdateAsync(id, dto.Radius, dto.Height);
            return NoContent();
        }

        /// <summary>
        /// Deletes a cylinder by ID.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _service.DeleteAsync(id);
            return NoContent();
        }
    }

    public record CylinderDto(double Radius, double Height);
}
