namespace TrafficLightControl.Models
{
    public enum TrafficLightState
    {
        Red,
        Yellow,
        Green
    }
}
